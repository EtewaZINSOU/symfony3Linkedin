<?php

/* item/add.html.twig */
class __TwigTemplate_40ccd1e43840f4e7ff64e62426aa7106ad3f5b25c434477ca44ff711a24051f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "item/add.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_135cee4a02a99f9ac5b2be20b47f82a80bd810757c9e5d6a4f3678e75dc64d0f = $this->env->getExtension("native_profiler");
        $__internal_135cee4a02a99f9ac5b2be20b47f82a80bd810757c9e5d6a4f3678e75dc64d0f->enter($__internal_135cee4a02a99f9ac5b2be20b47f82a80bd810757c9e5d6a4f3678e75dc64d0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "item/add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_135cee4a02a99f9ac5b2be20b47f82a80bd810757c9e5d6a4f3678e75dc64d0f->leave($__internal_135cee4a02a99f9ac5b2be20b47f82a80bd810757c9e5d6a4f3678e75dc64d0f_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_827f21fcfac42156a3ab5b4bffeee50fb83563a5d06c948c47fce1607f647c70 = $this->env->getExtension("native_profiler");
        $__internal_827f21fcfac42156a3ab5b4bffeee50fb83563a5d06c948c47fce1607f647c70->enter($__internal_827f21fcfac42156a3ab5b4bffeee50fb83563a5d06c948c47fce1607f647c70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container\">
        ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo " <br />

        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row');
        echo "
        ";
        // line 8
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'row');
        echo "
        ";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "code", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "collection", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "imageUrl", array()), 'row');
        echo "

        ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'widget');
        echo "
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "update", array()), 'widget', array("attr" => array("class" => "hide")));
        echo "
        ";
        // line 15
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "changeOwner", array()), 'widget', array("attr" => array("class" => "hide")));
        echo "

        ";
        // line 17
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_827f21fcfac42156a3ab5b4bffeee50fb83563a5d06c948c47fce1607f647c70->leave($__internal_827f21fcfac42156a3ab5b4bffeee50fb83563a5d06c948c47fce1607f647c70_prof);

    }

    public function getTemplateName()
    {
        return "item/add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 17,  77 => 15,  73 => 14,  69 => 13,  64 => 11,  60 => 10,  56 => 9,  52 => 8,  48 => 7,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/*     <div class="container">*/
/*         {{ form_start(form) }} <br />*/
/* */
/*         {{ form_row(form.title) }}*/
/*         {{ form_row(form.description) }}*/
/*         {{ form_row(form.code) }}*/
/*         {{ form_row(form.collection) }}*/
/*         {{ form_row(form.imageUrl) }}*/
/* */
/*         {{ form_widget(form.submit) }}*/
/*         {{ form_widget(form.update, {attr: {class: 'hide'}}) }}*/
/*         {{ form_widget(form.changeOwner, {attr: {class: 'hide'}}) }}*/
/* */
/*         {{ form_end(form) }}*/
/*     </div>*/
/* {% endblock %}*/
