<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_0e6ca7f6b596433c140795d9280f5aebc8cf8fe4d2f747aa0fbbe362a5532f23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d12e22c94aec941282e17769b14008186cc30625c655fb4c766fece2f2fec863 = $this->env->getExtension("native_profiler");
        $__internal_d12e22c94aec941282e17769b14008186cc30625c655fb4c766fece2f2fec863->enter($__internal_d12e22c94aec941282e17769b14008186cc30625c655fb4c766fece2f2fec863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d12e22c94aec941282e17769b14008186cc30625c655fb4c766fece2f2fec863->leave($__internal_d12e22c94aec941282e17769b14008186cc30625c655fb4c766fece2f2fec863_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_12902bd955f35cd5cd57aa8e4bcda0837ca901a563fcf132c4138546d8d6e8fd = $this->env->getExtension("native_profiler");
        $__internal_12902bd955f35cd5cd57aa8e4bcda0837ca901a563fcf132c4138546d8d6e8fd->enter($__internal_12902bd955f35cd5cd57aa8e4bcda0837ca901a563fcf132c4138546d8d6e8fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_12902bd955f35cd5cd57aa8e4bcda0837ca901a563fcf132c4138546d8d6e8fd->leave($__internal_12902bd955f35cd5cd57aa8e4bcda0837ca901a563fcf132c4138546d8d6e8fd_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
