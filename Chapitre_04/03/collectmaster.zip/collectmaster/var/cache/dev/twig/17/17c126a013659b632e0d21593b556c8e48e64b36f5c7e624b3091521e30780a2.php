<?php

/* item/list.html.twig */
class __TwigTemplate_ac245ae3b9012869a65a2563aa80beca1cfbb320598ce1edf18a076bbab250ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "item/list.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de3c71edacf476222fb6b27e6524aa01f71150561e22f4a544d83e4270ed8e1a = $this->env->getExtension("native_profiler");
        $__internal_de3c71edacf476222fb6b27e6524aa01f71150561e22f4a544d83e4270ed8e1a->enter($__internal_de3c71edacf476222fb6b27e6524aa01f71150561e22f4a544d83e4270ed8e1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "item/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_de3c71edacf476222fb6b27e6524aa01f71150561e22f4a544d83e4270ed8e1a->leave($__internal_de3c71edacf476222fb6b27e6524aa01f71150561e22f4a544d83e4270ed8e1a_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_28f96d22d453c35fbd3a1085ee07352dbf710bfd8c6e2e2220e03b55d486ae5b = $this->env->getExtension("native_profiler");
        $__internal_28f96d22d453c35fbd3a1085ee07352dbf710bfd8c6e2e2220e03b55d486ae5b->enter($__internal_28f96d22d453c35fbd3a1085ee07352dbf710bfd8c6e2e2220e03b55d486ae5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    Filter by :
    ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["collections"]) ? $context["collections"] : $this->getContext($context, "collections")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            echo "        <a href=\"\" class=\"label label-info\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "collection", array()), "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "
    <div class=\"container\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["items"]) ? $context["items"] : $this->getContext($context, "items")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 11
            echo "            ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo " | <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oneItem", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\">View</a>

            ";
            // line 13
            if (($this->getAttribute($context["item"], "isAuthor", array(0 => $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())), "method") && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "hasRole", array(0 => "ROLE_USER"), "method"))) {
                // line 14
                echo "                | <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("removeItem", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\">Remove</a>
            ";
            }
            // line 16
            echo "
            <br />
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    </div>
";
        
        $__internal_28f96d22d453c35fbd3a1085ee07352dbf710bfd8c6e2e2220e03b55d486ae5b->leave($__internal_28f96d22d453c35fbd3a1085ee07352dbf710bfd8c6e2e2220e03b55d486ae5b_prof);

    }

    public function getTemplateName()
    {
        return "item/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 19,  80 => 16,  74 => 14,  72 => 13,  64 => 11,  60 => 10,  56 => 8,  47 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/*     Filter by :*/
/*     {% for item in collections %}*/
/*         <a href="" class="label label-info">{{ item.collection }}</a>*/
/*     {% endfor %}*/
/* */
/*     <div class="container">*/
/*         {% for item in items %}*/
/*             {{ item.title }} | <a href="{{ path('oneItem', {id: item.id}) }}">View</a>*/
/* */
/*             {% if (item.isAuthor(app.user) and app.user.hasRole('ROLE_USER')) %}*/
/*                 | <a href="{{ path('removeItem', {id: item.id}) }}">Remove</a>*/
/*             {% endif %}*/
/* */
/*             <br />*/
/*         {% endfor %}*/
/*     </div>*/
/* {% endblock %}*/
