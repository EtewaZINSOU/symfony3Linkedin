<?php

/* base.html.twig */
class __TwigTemplate_fdfcef2b012527a9434f7d6d167d97f0272ef7f0a61784edd6a9bfe52f29cc44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'menu' => array($this, 'block_menu'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97c0572c812e5961f228b0ca6080d3cd95cd74483b8edaf5dd929e8933da1fc1 = $this->env->getExtension("native_profiler");
        $__internal_97c0572c812e5961f228b0ca6080d3cd95cd74483b8edaf5dd929e8933da1fc1->enter($__internal_97c0572c812e5961f228b0ca6080d3cd95cd74483b8edaf5dd929e8933da1fc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <div class=\"container\">
            ";
        // line 14
        $this->displayBlock('menu', $context, $blocks);
        // line 36
        echo "
            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "infos"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 38
            echo "                <div class=\"alert alert-success\">
                    ";
            // line 39
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "
            ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "errors"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 44
            echo "                <div class=\"alert alert-danger\">
                    ";
            // line 45
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
            ";
        // line 49
        $this->displayBlock('main', $context, $blocks);
        // line 50
        echo "        </div>
        ";
        // line 51
        $this->displayBlock('javascripts', $context, $blocks);
        // line 53
        echo "    </body>
</html>
";
        
        $__internal_97c0572c812e5961f228b0ca6080d3cd95cd74483b8edaf5dd929e8933da1fc1->leave($__internal_97c0572c812e5961f228b0ca6080d3cd95cd74483b8edaf5dd929e8933da1fc1_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0838fa3ab7bc6aa1e9313868ec2f20ea370609690bba76879c2d803541724653 = $this->env->getExtension("native_profiler");
        $__internal_0838fa3ab7bc6aa1e9313868ec2f20ea370609690bba76879c2d803541724653->enter($__internal_0838fa3ab7bc6aa1e9313868ec2f20ea370609690bba76879c2d803541724653_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Collectmaster!";
        
        $__internal_0838fa3ab7bc6aa1e9313868ec2f20ea370609690bba76879c2d803541724653->leave($__internal_0838fa3ab7bc6aa1e9313868ec2f20ea370609690bba76879c2d803541724653_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3faff3aedc2bd9218c82d2b62ecea178294682e06ee35ab7c452df64b0d0d266 = $this->env->getExtension("native_profiler");
        $__internal_3faff3aedc2bd9218c82d2b62ecea178294682e06ee35ab7c452df64b0d0d266->enter($__internal_3faff3aedc2bd9218c82d2b62ecea178294682e06ee35ab7c452df64b0d0d266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" href=\"/vendors/bootstrap/dist/css/bootstrap.css\">
            <link rel=\"stylesheet\" href=\"/css/collectmaster.css\">
        ";
        
        $__internal_3faff3aedc2bd9218c82d2b62ecea178294682e06ee35ab7c452df64b0d0d266->leave($__internal_3faff3aedc2bd9218c82d2b62ecea178294682e06ee35ab7c452df64b0d0d266_prof);

    }

    // line 14
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e9ccfa14165c13abe704b04c0beeecebe662399b635753993aeca35e04fd4f94 = $this->env->getExtension("native_profiler");
        $__internal_e9ccfa14165c13abe704b04c0beeecebe662399b635753993aeca35e04fd4f94->enter($__internal_e9ccfa14165c13abe704b04c0beeecebe662399b635753993aeca35e04fd4f94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 15
        echo "                <nav class=\"navbar navbar-default\">
                    <div class=\"container-fluid\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"#\">CollectMaster</a>
                        </div>
                        <div id=\"navbar\" class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav\">
                                <li class=\"active\"><a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Home</a></li>
                                <li><a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("items");
        echo "\">Collection</a></li>
                            </ul>
                            <a class=\"pull-right btn btn-info account\" href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
        echo "\">Login</a>
                        </div><!--/.nav-collapse -->
                    </div><!--/.container-fluid -->
                </nav>

                ";
        // line 30
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 31
            echo "                <div class=\"text-right\">
                    Hello ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " ! | <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\">Logout</a>
                </div>
                ";
        }
        // line 35
        echo "            ";
        
        $__internal_e9ccfa14165c13abe704b04c0beeecebe662399b635753993aeca35e04fd4f94->leave($__internal_e9ccfa14165c13abe704b04c0beeecebe662399b635753993aeca35e04fd4f94_prof);

    }

    // line 49
    public function block_main($context, array $blocks = array())
    {
        $__internal_80e72695429e144f0ae5af4d2870b7ac51b687f5adc669fc5cf42dfcf361dba2 = $this->env->getExtension("native_profiler");
        $__internal_80e72695429e144f0ae5af4d2870b7ac51b687f5adc669fc5cf42dfcf361dba2->enter($__internal_80e72695429e144f0ae5af4d2870b7ac51b687f5adc669fc5cf42dfcf361dba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_80e72695429e144f0ae5af4d2870b7ac51b687f5adc669fc5cf42dfcf361dba2->leave($__internal_80e72695429e144f0ae5af4d2870b7ac51b687f5adc669fc5cf42dfcf361dba2_prof);

    }

    // line 51
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_528cc19d382cbc234cd91a9a76a9568cbec007b182ac8bd94d7b3573c38c2699 = $this->env->getExtension("native_profiler");
        $__internal_528cc19d382cbc234cd91a9a76a9568cbec007b182ac8bd94d7b3573c38c2699->enter($__internal_528cc19d382cbc234cd91a9a76a9568cbec007b182ac8bd94d7b3573c38c2699_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 52
        echo "        ";
        
        $__internal_528cc19d382cbc234cd91a9a76a9568cbec007b182ac8bd94d7b3573c38c2699->leave($__internal_528cc19d382cbc234cd91a9a76a9568cbec007b182ac8bd94d7b3573c38c2699_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  202 => 52,  196 => 51,  185 => 49,  178 => 35,  170 => 32,  167 => 31,  165 => 30,  157 => 25,  152 => 23,  148 => 22,  139 => 15,  133 => 14,  124 => 7,  118 => 6,  106 => 5,  97 => 53,  95 => 51,  92 => 50,  90 => 49,  87 => 48,  78 => 45,  75 => 44,  71 => 43,  68 => 42,  59 => 39,  56 => 38,  52 => 37,  49 => 36,  47 => 14,  39 => 10,  37 => 6,  33 => 5,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Collectmaster!{% endblock %}</title>*/
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" href="/vendors/bootstrap/dist/css/bootstrap.css">*/
/*             <link rel="stylesheet" href="/css/collectmaster.css">*/
/*         {% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         <div class="container">*/
/*             {% block menu %}*/
/*                 <nav class="navbar navbar-default">*/
/*                     <div class="container-fluid">*/
/*                         <div class="navbar-header">*/
/*                             <a class="navbar-brand" href="#">CollectMaster</a>*/
/*                         </div>*/
/*                         <div id="navbar" class="navbar-collapse collapse">*/
/*                             <ul class="nav navbar-nav">*/
/*                                 <li class="active"><a href="{{ path('homepage') }}">Home</a></li>*/
/*                                 <li><a href="{{ path('items') }}">Collection</a></li>*/
/*                             </ul>*/
/*                             <a class="pull-right btn btn-info account" href="{{ path('fos_user_security_login') }}">Login</a>*/
/*                         </div><!--/.nav-collapse -->*/
/*                     </div><!--/.container-fluid -->*/
/*                 </nav>*/
/* */
/*                 {% if app.user %}*/
/*                 <div class="text-right">*/
/*                     Hello {{ app.user.username }} ! | <a href="{{ path('fos_user_security_logout') }}">Logout</a>*/
/*                 </div>*/
/*                 {% endif %}*/
/*             {% endblock %}*/
/* */
/*             {% for message in app.session.flashbag.get('infos') %}*/
/*                 <div class="alert alert-success">*/
/*                     {{ message }}*/
/*                 </div>*/
/*             {% endfor %}*/
/* */
/*             {% for message in app.session.flashbag.get('errors') %}*/
/*                 <div class="alert alert-danger">*/
/*                     {{ message }}*/
/*                 </div>*/
/*             {% endfor %}*/
/* */
/*             {% block main %}{% endblock %}*/
/*         </div>*/
/*         {% block javascripts %}*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
