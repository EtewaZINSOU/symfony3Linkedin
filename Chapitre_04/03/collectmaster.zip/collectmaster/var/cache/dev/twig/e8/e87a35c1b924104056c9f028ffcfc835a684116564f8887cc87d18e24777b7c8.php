<?php

/* homepage/index.html.twig */
class __TwigTemplate_e5baeb0b018a16a88bb732f6ef937105da343c156d77b24a7c711b1612ed9221 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "homepage/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6ec60248e88bf1a5d88c73986a2be07e1498160f38f21b4e9fdc32c3c02e53f = $this->env->getExtension("native_profiler");
        $__internal_e6ec60248e88bf1a5d88c73986a2be07e1498160f38f21b4e9fdc32c3c02e53f->enter($__internal_e6ec60248e88bf1a5d88c73986a2be07e1498160f38f21b4e9fdc32c3c02e53f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e6ec60248e88bf1a5d88c73986a2be07e1498160f38f21b4e9fdc32c3c02e53f->leave($__internal_e6ec60248e88bf1a5d88c73986a2be07e1498160f38f21b4e9fdc32c3c02e53f_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_573062777a74ed6cdc5f04b76ebf03c4e757d1afad5e8d458f943af53038bd6a = $this->env->getExtension("native_profiler");
        $__internal_573062777a74ed6cdc5f04b76ebf03c4e757d1afad5e8d458f943af53038bd6a->enter($__internal_573062777a74ed6cdc5f04b76ebf03c4e757d1afad5e8d458f943af53038bd6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"jumbotron\">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores atque consectetur, culpa deleniti distinctio dolore eaque eius ex, illo labore maxime nemo obcaecati quis quisquam, saepe similique sint unde!
    </div>
";
        
        $__internal_573062777a74ed6cdc5f04b76ebf03c4e757d1afad5e8d458f943af53038bd6a->leave($__internal_573062777a74ed6cdc5f04b76ebf03c4e757d1afad5e8d458f943af53038bd6a_prof);

    }

    public function getTemplateName()
    {
        return "homepage/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/*     <div class="jumbotron">*/
/*         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores atque consectetur, culpa deleniti distinctio dolore eaque eius ex, illo labore maxime nemo obcaecati quis quisquam, saepe similique sint unde!*/
/*     </div>*/
/* {% endblock %}*/
