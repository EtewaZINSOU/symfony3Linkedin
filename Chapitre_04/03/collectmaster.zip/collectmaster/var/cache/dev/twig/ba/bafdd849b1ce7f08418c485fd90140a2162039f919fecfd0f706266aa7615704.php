<?php

/* item/one.html.twig */
class __TwigTemplate_5ec6b85d5705fc81b292260aee7d12464afa11d1353762bca6238a23f40d5b4b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "item/one.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3167fdf7d76b5646664238c43422657fa101d30c050a58adb7904163dc3a47d5 = $this->env->getExtension("native_profiler");
        $__internal_3167fdf7d76b5646664238c43422657fa101d30c050a58adb7904163dc3a47d5->enter($__internal_3167fdf7d76b5646664238c43422657fa101d30c050a58adb7904163dc3a47d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "item/one.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3167fdf7d76b5646664238c43422657fa101d30c050a58adb7904163dc3a47d5->leave($__internal_3167fdf7d76b5646664238c43422657fa101d30c050a58adb7904163dc3a47d5_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_a0b4bf7e4e461a0b48657b6c4dd8be3873e0c34d825834e558ea5ba9064362b9 = $this->env->getExtension("native_profiler");
        $__internal_a0b4bf7e4e461a0b48657b6c4dd8be3873e0c34d825834e558ea5ba9064362b9->enter($__internal_a0b4bf7e4e461a0b48657b6c4dd8be3873e0c34d825834e558ea5ba9064362b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container\">
        ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo " <br />

        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row');
        echo "
        ";
        // line 8
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'row');
        echo "
        ";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "code", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "collection", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "imageUrl", array()), 'row');
        echo "

        ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'widget', array("attr" => array("class" => "hide")));
        echo "
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "update", array()), 'widget');
        echo "

        ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "changeOwner", array()), 'widget', array("attr" => array("class" => (isset($context["hideChangeOwner"]) ? $context["hideChangeOwner"] : $this->getContext($context, "hideChangeOwner")))));
        echo "

        ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_a0b4bf7e4e461a0b48657b6c4dd8be3873e0c34d825834e558ea5ba9064362b9->leave($__internal_a0b4bf7e4e461a0b48657b6c4dd8be3873e0c34d825834e558ea5ba9064362b9_prof);

    }

    public function getTemplateName()
    {
        return "item/one.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 18,  78 => 16,  73 => 14,  69 => 13,  64 => 11,  60 => 10,  56 => 9,  52 => 8,  48 => 7,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/*     <div class="container">*/
/*         {{ form_start(form) }} <br />*/
/* */
/*         {{ form_row(form.title) }}*/
/*         {{ form_row(form.description) }}*/
/*         {{ form_row(form.code) }}*/
/*         {{ form_row(form.collection) }}*/
/*         {{ form_row(form.imageUrl) }}*/
/* */
/*         {{ form_widget(form.submit, {attr: {class: 'hide'}}) }}*/
/*         {{ form_widget(form.update) }}*/
/* */
/*         {{ form_widget(form.changeOwner, {attr: {class: hideChangeOwner }}) }}*/
/* */
/*         {{ form_end(form) }}*/
/*     </div>*/
/* {% endblock %}*/
