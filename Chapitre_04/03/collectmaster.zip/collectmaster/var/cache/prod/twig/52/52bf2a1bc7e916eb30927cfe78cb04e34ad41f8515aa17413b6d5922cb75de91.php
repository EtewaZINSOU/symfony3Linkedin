<?php

/* homepage/index.html.twig */
class __TwigTemplate_429b1a5150862b59faea2fd0a77ee7e3f38b43e7c838b8deb429b741d8a454d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "homepage/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"jumbotron\">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores atque consectetur, culpa deleniti distinctio dolore eaque eius ex, illo labore maxime nemo obcaecati quis quisquam, saepe similique sint unde!
    </div>
";
    }

    public function getTemplateName()
    {
        return "homepage/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/*     <div class="jumbotron">*/
/*         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores atque consectetur, culpa deleniti distinctio dolore eaque eius ex, illo labore maxime nemo obcaecati quis quisquam, saepe similique sint unde!*/
/*     </div>*/
/* {% endblock %}*/
